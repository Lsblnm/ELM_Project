<template>
	<div class="wrapper">
	<header>
		<p>流水</p>
	</header>
	<ul class="transcation">
		<li v-for="item in transcationArr" >
			<div class="trancation-info">
				<p>
					{{item}}
				</p>
			</div>
		</li>
	</ul>
	</div>
</template>

<script>
	export default{
		name:'Transcation',
		data(){
			return {
			transcationArr:[],
			}
		},
	created(){

		this.user = this.$getSessionStorage('user');
		
		this.$axios.post('VirtualWalletController/listtransactionbyid', this.$qs.stringify({
			userid: this.user.userId
		})).then(response => {
			let result = response.data;
			console.log(result);
			this.transcationArr = result;
			
		}).catch(error => {
			console.error(error);
		});
	}
	}
</script>

<style scoped>
/* 添加样式规则 */
.wrapper {
  width: 100%;
  max-width: 800px; /* 调整最大宽度 */
  margin: 0 auto;
  padding: 20px;
}

header {
  background-color: #007bff;
  color: #fff;
  text-align: center;
  padding: 10px 0;
}

.transaction-list {
  list-style: none;
  padding: 0;
}

.transaction-item {
  margin-bottom: 20px;
  background-color: #f5f5f5; /* 调整背景颜色 */
  border: 1px solid #ddd; /* 添加边框 */
  border-radius: 5px;
  padding: 10px;
}

.transaction-info p {
  margin: 0;
}
</style>
